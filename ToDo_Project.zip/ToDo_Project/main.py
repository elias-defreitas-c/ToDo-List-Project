from local_db_test import *
import datetime


class Entry(db.Model):
    __entry__ = 'entry'
    EntryID = db.Column(db.Integer, primary_key=True, autoincrement=True)
    entry = db.Column(db.String(50))
    created_at = db.Column(db.DateTime, default=datetime.datetime.now)


def start():
    print(
        "What do you want to do?\nDo you want to:\n1. Add something you want to do?\n2. Delete something you already "
        "did?\n3.Exit?")
    descision = input(": ")
    if descision == "1":
        print(1)


def get_entry():
    entry_text = input("Was wollen sie hinzufügen: ")
    return entry_text


@app.route('/test')
def create_entry():
    entry_text = get_entry()
    try:
        new_entry = Entry(entry=entry_text)
        db.session.add(new_entry)
        db.session.commit()
        return "Entry created successfully!"
    except Exception as e:
        # Handle the exception
        error_text = "<p>The error:<br>" + str(e) + "</p>"
        hed = '<h1>Something is broken.</h1>'
        return hed + error_text


if __name__ == '__main__':
    app.run()
